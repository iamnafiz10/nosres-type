import React from 'react';
import DashboardPage from "../Components/DashboardPage/DashboardPage";

function Dashboard() {
    return (
        <>
            <DashboardPage/>
        </>
    );
}

export default Dashboard;