import React from 'react';
import PersonalInfoPage from "../Components/PersonalInfoPage/PersonalInfoPage";

function PersonalInfo() {
    return (
        <>
            <PersonalInfoPage/>
        </>
    );
}

export default PersonalInfo;